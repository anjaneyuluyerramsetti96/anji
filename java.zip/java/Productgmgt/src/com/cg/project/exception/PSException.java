package com.cg.project.exception;

public class PSException extends Exception{

	public PSException(String message) {
		super(message);
		
	}
	
	

}
