package com.cg.project.service;

import java.util.regex.Pattern;

import com.cg.project.exception.PSException;

public class ServiceImpl implements Service {

	@Override
	public boolean isNameValid(String productName) throws PSException {
		
		String regEx="^[A-Z]{1}[a-zA-Z ]{4,}$";
		boolean nameValidFalg=false;
		if(!Pattern.matches(regEx, productName)) {
			throw new PSException("First Letter should be Capital and greater than 5 charaacters");
		}else {
			nameValidFalg=true;
		}
		return nameValidFalg;
		
		
	}

	@Override
	public boolean isCostValid(int productCost) throws PSException {
		
		boolean costValidFlag=false;
		if(productCost < 5000) {
			throw new PSException("Cost should be greater than 5000");
		}else {
			costValidFlag=true;
		}
		return costValidFlag;
	}

}
