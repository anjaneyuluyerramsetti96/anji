import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
    
  employees:Employee[]=[
    {eid:112,name:"Anji",salary:25233.56,gender:"male"},
    {eid:113,name:"Harsha",salary:52233.67,gender:"male"},
    {eid:104,name:"Srinu",salary:29325.86,gender:"male"},
    {eid:105,name:"Satya",salary:32501.69,gender:"male"},
    {eid:116,name:"lakshmi",salary:42501.98,gender:"female"},
  ];
   
  constructor() { }
  getAllEmployees():Employee[]{
    return this.employees;
  }
  addEmployee(employee:Employee){
    this.employees.push(employee);
    return true;
  }
  deleteEmployee(i:number){
    this.employees.splice(i,1);
  }
}
