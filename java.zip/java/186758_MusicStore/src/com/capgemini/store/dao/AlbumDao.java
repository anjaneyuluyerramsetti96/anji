package com.capgemini.store.dao;

import com.capgemini.store.bean.Album;

public interface AlbumDao {

	int saveAlbum(Album album);

	Album albumFind(int albumId);

	

}
