package com.cg.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.bean.Feedback;
import com.cg.exception.FeedbackException;
import com.cg.service.FeedbackService;
import com.cg.service.IFeedbackService;



public class Client {

	public static void main(String[] args) {
		
		IFeedbackService service=new FeedbackService();
		Scanner scanner=null;
		int choice=0;
		String name="";
		int rating=0;
		String topic="";
		String continueChoice="";
		boolean continuevalue=false;
		boolean choiceflag=false;
		boolean ratingflag=false;
		boolean topicflag=false;
		boolean nameflag=false;
		do {
			System.out.println("*****Welcome to feedback******");
			System.out.println("1.Add");
			System.out.println("2.Display");
			System.out.println("3.exit");
			try {
				scanner = new Scanner(System.in);
				System.out.println("enter choice");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					do {
						scanner = new Scanner(System.in);

						try {
							System.out.println("enter name");

							name = scanner.nextLine();
							service.validateName(name);
							nameflag = true;
						} catch (FeedbackException e) {
							
							nameflag = false;
							System.err.println(e.getMessage());
						}
					} while (!nameflag);

					do {
						scanner = new Scanner(System.in);

						try {
							System.out.println("enter rating");

							rating = scanner.nextInt();
							service.validateRating(rating);
							ratingflag = true;
						} catch (FeedbackException e) {
						    ratingflag = false;
							System.err.println(e.getMessage());
						}
					} while (!ratingflag);
					do {
						scanner = new Scanner(System.in);

						try {
							System.out.println("enter topic");

							topic = scanner.nextLine();
							service.validateTopic(topic);
							topicflag = true;
						} catch (FeedbackException e) {
							topicflag = false;
							System.err.println(e.getMessage());
						}
					} while (!topicflag);

					 Feedback feed=new Feedback(name, rating, topic);
					 Map<String, Integer>map=new HashMap<>();
					 map=service.addFeedbackDetails(name,rating,topic);
					 System.out.println(map);
					break;
				case 2:Map<String, Integer>feedbackmap=service.getFeedbackReport();
				System.out.println(feedbackmap);
					break;
				case 3:
					System.out.println("Thank u");
					System.exit(0);
					break;
				default:
					System.err.println("enter 1 or 2 or 3 only");
					break;
				}
			} catch (InputMismatchException e) {
				// TODO Auto-generated catch block
				System.err.println("enter only digits");
			}
			
		} while (!choiceflag);
       scanner.close();
	}

}
