package com.cg.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.Exception.EmployeeException;
import com.cg.employee.dto.Employee;
import com.cg.employee.service.EmployeeService;

@RestController
@RequestMapping("/application")
public class EmployeeController {
    @Autowired
	private EmployeeService empService;
	//@RequestMapping("/employees")
	@GetMapping("/employees")
 public List<Employee> viewEmployeeList() throws EmployeeException
 {
	 return empService.viewEmployeeList();
 }

	//@RequestMapping(value = "/employees",method = RequestMethod.POST)
	@PostMapping("/employees")
	public List<Employee> createEmployee(@RequestBody Employee employee)throws EmployeeException{
		return empService.createEmployee(employee);

	}
	//@RequestMapping(value = "/employees/{id}",method = RequestMethod.POST)
	@DeleteMapping("/employees/{id}")
	public List<Employee> deleteEmployee(@PathVariable int id)throws EmployeeException{
		return empService.deleteEmployee(id);
	}
	//@RequestMapping(value = "/employees/{id}",method = RequestMethod.PUT)
	@PutMapping("/employees")
	public List<Employee> updateEmployee(@RequestBody Employee employee)throws EmployeeException{
		return empService.updateEmployee(employee);
	}
	@GetMapping("/getbyid")
	public Employee findEmployeeById(@RequestParam int id) throws EmployeeException{
		
		return empService.findEmployeeById(id);
	}
	@GetMapping("employees/{deptName}")
	public List<Employee>viewEmployeeByDept(@PathVariable String deptName)throws EmployeeException{
		return empService.viewEmployeeByDepartment(deptName);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleErrors(Exception ex){
		ex.printStackTrace();
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
}
