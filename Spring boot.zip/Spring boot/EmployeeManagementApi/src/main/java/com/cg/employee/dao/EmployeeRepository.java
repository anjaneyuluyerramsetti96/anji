package com.cg.employee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.employee.dto.Employee;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	 @Query("from Employee where deptName=:deptName")
	 List<Employee> viewEmployeeByDepartment(@Param("deptName") String deptName);
}
