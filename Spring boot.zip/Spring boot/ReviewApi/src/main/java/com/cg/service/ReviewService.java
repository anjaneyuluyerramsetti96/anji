package com.cg.service;

import java.util.List;

import com.cg.dto.Review;
import com.cg.exception.ReviewException;

public interface ReviewService {
	List<Review> getAllReviews() throws ReviewException;
	List<Review> addReview(Review review) throws ReviewException;
	List<Review> deleteReview(int Id) throws ReviewException;
	List<Review> editReview(int Id,Review review)throws ReviewException;
}
