package com.capgemini.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.BankDao;
import com.capgemini.dao.BankDaoImpl;
import com.capgemini.exception.BankExceptions;

public class BankServiceImpl implements BankService{

	BankDao dao=new BankDaoImpl();

	@Override
	public long addDetails(Account account) {
		long accountNo=(long)(Math.random()*100000000);
		account.setAccountNo(accountNo);
		
		return dao.addDetails(account);
	}

	@Override
	public Map<Long, Account> accountDetails(Account account) {
		
		return dao.accountDetails(account);
	}

	@Override
	public long addDeposit(long accountNo, long depositAmount) {
		
		return dao.addDeposit(accountNo, depositAmount);
	}

	@Override
	public long addWithDraw(long accountNo, long withDrawAmount) {
		
		return dao.addWithDraw(accountNo, withDrawAmount);
	}

	@Override
	public double balanceCheck() {
		
		return dao.balanceCheck();
	}

	@Override
	public long fundDetails(long accountNo, long fundAmount) {
		
		return dao.fundDetails(accountNo, fundAmount);
	}

	@Override
	public int addTransaction(Transaction transaction) {
		int id=(int)(Math.random()*1000);
		transaction.setTransactionId(id);
		return dao.addTransaction(transaction);
	}

	@Override
	public Map<Integer, Transaction> transactionDetails(Transaction transaction) {
		
		return dao.transactionDetails(transaction);
	}
	
	@Override
	public boolean validateName(String name) throws BankExceptions {

		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankExceptions("First letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
	@Override
	public boolean validateGender(String gender) throws BankExceptions {
		boolean resultFlag=false;
		if(gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female")) {
			resultFlag = true;
		}else {
			
			throw new BankExceptions("Gender should be only Male or Female");
		}
		return resultFlag;
	}
	@Override
	public boolean validateBalance(double balance) throws BankExceptions{
		boolean resultFlag=false;
		if(balance<0) {
			throw new BankExceptions("Balance should be greater than Zero");
		}else {
			resultFlag=true;
		}
		return resultFlag;
		
	}
}
