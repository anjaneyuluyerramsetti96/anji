package com.cg.proect.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.project.exception.PSException;
import com.cg.project.service.Service;
import com.cg.project.service.ServiceImpl;

public class MainUI {

	public static void main(String[] args) {
	
		System.out.println("Product mgmt system");
		
		Service service=new ServiceImpl();
		
		Scanner scanner=null;
		int choice=0;
		boolean choiceFlag=false;
		
		do {
			System.out.println("1.Add Product");
			System.out.println("2.Exit");
			
			scanner=new Scanner(System.in);
			
			try {
				choice=scanner.nextInt();
				choiceFlag=true;
				
				String productName="";
				boolean nameFlag=false;
				switch (choice) {
				case 1:
					
					do {
						System.out.println("Enter Product Name");
						scanner=new Scanner(System.in);
						 try {
							productName=scanner.nextLine();
							 nameFlag=true;
							 service.isNameValid(productName);
							 
						} catch (PSException e) {
							nameFlag=false;
							System.err.println(e.getMessage());
						}
						 
						
					} while (!nameFlag);
					
					int productCost=0;
					boolean productCostFlag=false;
					do {
						System.out.println("Enter Product cost");
						scanner=new Scanner(System.in);
						
						try {
							productCost=scanner.nextInt();
							productCostFlag=true;
							service.isCostValid(productCost);
						} catch (PSException e) {
							productCostFlag=false;
							System.err.println(e.getMessage());
						}
					} while (!productCostFlag);
					
					break;

				case 2:
					System.out.println("Thanks for your Visit");
					System.exit(0);
					break;
					
				default:
					System.err.println("Please enter 1 and 2 only");
					break;
				}
				
				
				
			} catch (InputMismatchException e) {
				choiceFlag=false;
				System.err.println("Enter Valid Choice");
			}
			
			
			
		}while(!choiceFlag);
	}

}
