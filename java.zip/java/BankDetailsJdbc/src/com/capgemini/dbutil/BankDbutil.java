package com.capgemini.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BankDbutil {
	 private static Connection connection=null;
	  public static Connection getConnection() {
		  try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver();
			 String url="jdbc:oracle:thin:@localhost:1521:XE";
			connection=DriverManager.getConnection(url, "scott", "tiger");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		  
		 
		  return connection;
	  }

	
}
