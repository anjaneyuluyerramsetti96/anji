package com.cg.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.Exception.EmployeeException;
import com.cg.employee.dao.EmployeeRepository;
import com.cg.employee.dto.Employee;
/**
 * 
 * @author anjyerra
 *Date of Creation:23-08-2019
 *class Employee Service Implementation
 *Description:
 */
@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
	private EmployeeRepository empdao;
    /**
	 * Author:anjyerra
	 * Date:23-08-2019
	 * Method Name:view employee list
	 * Parameters :Nil
	 * return value:List of employees
	 * purpose:To Retrieve all employees from the database/
	 */
	@Override
	public List<Employee> viewEmployeeList() throws EmployeeException {
		try {
			return empdao.findAll();
		} catch (Exception e) {
		throw new EmployeeException(e.getMessage());
		}
	
	}
	  /**
		 * Author:anjyerra
		 * Date:23-08-2019
		 * Method Name:create employee
		 * Parameters :employee
		 * return value:List of employees
		 * purpose:To Retrieve all employees from the database/
		 */
	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException {
		try {
			 
			empdao.save(employee);
			return viewEmployeeList();
		
		}catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	  /**
		 * Author:anjyerra
		 * Date:23-08-2019
		 * Method Name:deleteEmployee
		 * Parameters :integer variable
		 * return value:List of employees
		 * purpose:To Retrieve all employees from the database/
		 */

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(empdao.existsById(id)) {
			empdao.deleteById(id);
			return viewEmployeeList();
		}
		else
		{
		 throw new EmployeeException("Cannot Delete. Employee with Id " + id +" does not exist");
	}
	}

	  /**
		 * Author:anjyerra
		 * Date:23-08-2019
		 * Method Name:updateEmployee
		 * Parameters :employee
		 * return value:List of employees
		 * purpose:To Retrieve all employees from the database/
		 */
	@Override
	public List<Employee> updateEmployee( Employee employee) throws EmployeeException {
		if(empdao.existsById(employee.getEmpId())) {
			empdao.save(employee);
			return viewEmployeeList();
		}
		else {
			throw new EmployeeException("Invalid Employee.Cannot be updated");
		}
	}
	  /**
		 * Author:anjyerra
		 * Date:23-08-2019
		 * Method Name:view employee by department
		 * Parameters :String variable
		 * return value:List of employees
		 * purpose:To Retrieve all employees from the database/
		 */
	@Override
	public List<Employee> viewEmployeeByDepartment(String deptName) throws EmployeeException {
		return empdao.viewEmployeeByDepartment(deptName);
	}
	  /**
		 * Author:anjyerra
		 * Date:23-08-2019
		 * Method Name:find employee by id
		 * Parameters :integer variable
		 * return value:List of employees
		 * purpose:To Retrieve all employees from the database/
		 */
	@Override
	public Employee findEmployeeById(int id) throws EmployeeException {
		try {
			Optional<Employee> data=empdao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}
			else {
				throw new  EmployeeException("Employee with Id"+id+"does not exist");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}
}
