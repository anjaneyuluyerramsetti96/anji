package com.capgemini.store.bean;

public class Album {
    private int  albumId;
    private String title;
    private String artist;
    private double price;
    private double rating;
	public Album() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Album(int albumId, String title, String artist, double price, double rating) {
		super();
		this.albumId = albumId;
		this.title = title;
		this.artist = artist;
		this.price = price;
		this.rating = rating;
	}
	public int getAlbumId() {
		return albumId;
	}
	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Album [albumId=" + albumId + ", title=" + title + ", artist=" + artist + ", price=" + price
				+ ", rating=" + rating + "]";
	}
    
	
}
