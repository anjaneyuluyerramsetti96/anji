package com.cg.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.dao.FeedbackDao;
import com.cg.dao.IFeedbackDao;
import com.cg.exception.FeedbackException;

public class FeedbackService implements IFeedbackService {
        IFeedbackDao dao=new FeedbackDao();
	@Override
	public boolean validateName(String name) throws FeedbackException {
		String regx="^[A-Z]{1}[a-zA-Z]{4,}$";
		boolean nameflag=false;
		if(!Pattern.matches(regx, name))
			throw new FeedbackException("first letter should be capital and followed by 4 characters");
		else
			nameflag=true;
		return nameflag;
	}

	@Override
	public boolean validateRating(int rating) throws FeedbackException {
		  boolean ratingflag=false;
		if(rating<1 || rating>5)
			throw new FeedbackException("rating should be in between 1 and 5");
		else
			 ratingflag=true;
		return ratingflag;
	}

	@Override
	public boolean validateTopic(String topic) throws FeedbackException {
		boolean topicflag=false;
		if(topic.equals("English")||topic.equals("Math"))
			topicflag=true;
		else
			throw new FeedbackException("please enter English or Math");
		return topicflag;
	}

	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String topic) {
		
		return dao.addFeedbackDetails(name,rating,topic);
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		
		return dao.getFeedbackReport();
	}

}
