package com.capgemini.service;

import java.util.Map;

import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.BankExceptions;

public interface BankService {
	long addDetails(Account account);
	Map<Long,Account> accountDetails(Account account);
	long addDeposit(long accountNo,long depositAmount);
	long addWithDraw(long accountNo,long withDrawAmount);
	double balanceCheck();
	long fundDetails(long accountNo,long fundAmount);
	int addTransaction(Transaction transaction);
	Map<Integer, Transaction> transactionDetails(Transaction transaction);
	boolean validateName(String name) throws BankExceptions;
	boolean validateGender(String gender) throws BankExceptions;
	boolean validateBalance(double balance) throws BankExceptions;
}
