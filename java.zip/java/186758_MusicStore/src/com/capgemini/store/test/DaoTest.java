package com.capgemini.store.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.store.bean.Album;
import com.capgemini.store.dao.AlbumDao;
import com.capgemini.store.dao.AlbumDaoImpl;

public class DaoTest {
	static AlbumDao dao=null;
   Album album;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dao=new AlbumDaoImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@Before
	public void setUp() throws Exception {
		album =new Album(11, "Tulasi", "Keeravani",100, 5);
	}

	@After
	public void tearDown() throws Exception {
		album=null;
	}

	@Test
	public void test() {
		//assertTrue(dao.albumFind(album).size()> 0);
	}

}
