package com.capgemini.store.service;

import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.AlbumException;

public interface AlbumService {

	boolean isTitleValid(String title)throws AlbumException;

	boolean isArtistValid(String artist)throws AlbumException;

	boolean isPriceValid(int price)throws AlbumException;

	boolean isRatingValid(double rating)throws AlbumException;

	int saveAlbum(Album album);

	Album albumFind(int albumId);

	

}
