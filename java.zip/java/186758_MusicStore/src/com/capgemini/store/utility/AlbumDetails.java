package com.capgemini.store.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.store.bean.Album;

public class AlbumDetails {
     
	static Map<Integer,Album> map=new HashMap<>();
	 static {
		 map.put(10, new Album(10,"Bunny","Devi",200,4));
		 map.put(12, new Album(12,"Happy","Harish",300,3));
		 map.put(13, new Album(13,"Gabbar","Prasad",250,5));
		 map.put(15, new Album(15,"Tholiprema","Thaman",275,4.5));
	 }
	/**
	 * @return the map
	 */
	public static Map<Integer, Album> getMap() {
		return map;
	}
	/**
	 * @param map the map to set
	 */
	public static void setMap(Map<Integer, Album> map) {
		AlbumDetails.map = map;
	}
	 
}
