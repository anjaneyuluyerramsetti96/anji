export interface IMobile{
    id:number;
    name:string;
    price:number;
    brand:String;
}