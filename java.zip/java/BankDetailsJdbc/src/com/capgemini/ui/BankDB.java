package com.capgemini.ui;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;

public class BankDB {
		public static Map<Long, Customer> CustomerDB = new HashMap<>();
		static {
			CustomerDB.put(3862000001L, new Customer("AAAAAA","ABS@gmail.com","9870654321",3862000001L,1000.0f,"12345"));
			CustomerDB.put(3862000002L, new Customer("BBBBBB","RFD@gmail.com","7889605432",3862000002L,3000.0f,"32451"));
			CustomerDB.put(3862000003L, new Customer("CCCCCC","OPL@gmail.com","9987065432",3862000003L,5000.0f,"96785"));
			CustomerDB.put(3862000004L, new Customer("DDDDDD","BNM@gmail.com","7899654322",3862000004L,2000.0f,"99665"));
			CustomerDB.put(3862000005L, new Customer("EEEEEE","FGH@gmail.com","8976546789",3862000005L,9000.0f,"83283"));
		}
		public static Map<Long, Transaction> TransactionDB = new HashMap<>();
		
	}


