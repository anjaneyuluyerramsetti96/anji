package com.capgemini.UI;


import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.BankExceptions;
import com.capgemini.service.BankServiceImpl;


public class MainUI {
	static Scanner scanner=new Scanner(System.in);
	static BankServiceImpl service=new BankServiceImpl();
	public static void main(String[] args) {
		boolean choiceFlag = false;
		String continueChoice;
		boolean continueValue = false;

		do {
			try {
				System.out.println(" ***Welcome to Bank**** \n  1.Create Account \n 2.Deposit \n 3.Withdraw \n 4.FundTransfer\n 5.ShowBalance ");
				int choice = scanner.nextInt();
				switch (choice) {
				
				case 1:
					
				{
					boolean nameFlag = false;
					String name = null;
					long mobileNumber;
					String gender;
					double balance=0;
					System.out.println("Account creation");
					boolean flag = false;
					boolean NameFlag=false;
					boolean GenderFlag=false;
					boolean BalanceFlag=false;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your name:");
						name = scanner.nextLine();
						try {
							service.validateName(name);
							NameFlag = true;
						} catch (BankExceptions e) {
							NameFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!NameFlag);
					System.out.println("enter your mobile number");
					mobileNumber = scanner.nextLong();
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your Gender:");
						gender = scanner.nextLine();
						try {
							service.validateGender(gender);
							GenderFlag = true;
						} catch (BankExceptions e) {
							GenderFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!GenderFlag);
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your Balance:");
						balance = scanner.nextDouble();
						try {
							service.validateBalance(balance);
							BalanceFlag = true;
						} catch (BankExceptions e) {
							BalanceFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!BalanceFlag);
					Account account=new Account(0, balance, name, mobileNumber);
					long number=service.addDetails(account);
					System.out.println("Account created  succesfully and your Account Number is"+number);
					//System.out.println(service.accountDetails(account));
				
					
				}	break;
				case 2:
				{
					long accountNo;
					int depositAmount;
					System.out.println(" ***Welcome***");
					System.out.println("enter account Number");
					accountNo=scanner.nextLong();
					System.out.println("enter amount");
					depositAmount=scanner.nextInt();
					long deposit=service.addDeposit(accountNo, depositAmount);
					System.out.println(deposit);
					Date transactionDate=new Date();
					Transaction transaction=new Transaction(0, transactionDate, accountNo, deposit);
					int transactionId=service.addTransaction(transaction);
					//System.out.println(service.transactionDetails(transaction));
					
				}
					break;
				case 3:
				{
					long accountNo;
					int withdrawAmount;
					System.out.println(" ***Welcome***");
					System.out.println("enter account Number");
					accountNo=scanner.nextLong();
					System.out.println("enter amount");
					withdrawAmount=scanner.nextInt();
					long withdraw=service.addWithDraw(accountNo, withdrawAmount);
					
					
					System.out.println(withdraw);
					
					Date transactionDate=new Date();
					Transaction transaction=new Transaction(0, transactionDate, accountNo, withdraw);
					int transactionId=service.addTransaction(transaction);
					//System.out.println(service.transactionDetails(transaction));
					
					
				}break;
				case 4:
				{
					long accountNo,accountNo2;
					int amount;
					System.out.println(" ***Welcome***");
					System.out.println("enter account Number");
					accountNo=scanner.nextLong();
					System.out.println("enter account Number to where the fund need to be transferred");
					accountNo2=scanner.nextLong();
					System.out.println("enter amount");
					amount=scanner.nextInt();
					long fund=service.fundDetails(accountNo, amount);
					System.out.println(fund);
					Date transactionDate=new Date();
					Transaction transaction=new Transaction(0, transactionDate, accountNo, fund);
					int transactionId=service.addTransaction(transaction);
					//System.out.println(service.transactionDetails(transaction));
					
					
				}break;
				case 5:
				{
					long accountNo;
					System.out.println("enter account Number");
					accountNo=scanner.nextLong();
					System.out.println("Your account Blance is="+service.balanceCheck());
				}break;
				
				default:
					System.out.println("choice should be 1,2,3,4,5");
					break;
				}

			} catch (InputMismatchException e) {
				choiceFlag = false;
				System.err.println("input should contains digits");
			}
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		

		scanner.close();
	}

	}