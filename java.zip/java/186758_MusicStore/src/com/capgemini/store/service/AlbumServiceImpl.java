package com.capgemini.store.service;

import java.util.regex.Pattern;

import com.capgemini.store.bean.Album;
import com.capgemini.store.dao.AlbumDao;
import com.capgemini.store.dao.AlbumDaoImpl;
import com.capgemini.store.exception.AlbumException;



public class AlbumServiceImpl implements AlbumService {
     AlbumDao dao=new AlbumDaoImpl();
	@Override
	public boolean isTitleValid(String title) throws AlbumException {
		String regx="^[A-Z]{1}[a-zA-Z]{4,}$";
		boolean nameflag=false;
		if(!Pattern.matches(regx, title))
			throw new AlbumException("first letter should be capital and followed by 4 characters");
		else
			nameflag=true;
		return nameflag;
	}

	@Override
	public boolean isArtistValid(String artist) throws AlbumException {
		String regx="^[A-Z]{1}[a-zA-Z]{4,}$";
		boolean nameflag=false;
		if(!Pattern.matches(regx, artist))
			throw new AlbumException("first letter should be capital and followed by 4 characters");
		else
			nameflag=true;
		return nameflag;
	}

	@Override
	public boolean isPriceValid(int price) throws AlbumException {
		boolean priceflag=false;
		if(price<0)
			throw new AlbumException("price should be greater than 0");
		else
			priceflag=true;
		return priceflag;
	}

	@Override
	public boolean isRatingValid(double rating) throws AlbumException {
		boolean ratingflag=false;
		if(rating<1||rating>5)
			throw new AlbumException("Rating should be in between 1 and 5 only");
		else
			ratingflag=true;
		return ratingflag;
	}

	@Override
	public int saveAlbum(Album album) {
		
		return dao.saveAlbum(album);
	}

	@Override
	public Album albumFind(int albumId) {
		
		return dao.albumFind(albumId);
	}

	

}
