package com.cg.project.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.project.bean.Product;

public class ProductDB {
	
	public static Map<Integer, Product> productList=new HashMap<>();
	
	static {
		
		productList.put(111,new Product(111,"Mobile", 10000) );
		productList.put(222,new Product(222,"Mobile", 20000) );
		productList.put(333,new Product(333,"Mobile", 30000) );
		productList.put(444,new Product(444,"Mobile", 40000) );
		
	}

	public static Map<Integer, Product> getProductList() {
		return productList;
	}

	public static void setProductList(Map<Integer, Product> productList) {
		ProductDB.productList = productList;
	}
	
	

}
