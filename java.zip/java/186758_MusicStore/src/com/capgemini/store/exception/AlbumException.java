package com.capgemini.store.exception;

public class AlbumException extends Exception{
   public AlbumException(String message) {
     super(message);
}
}
