package com.cg.exception;

public class ReviewException extends Exception{

	public ReviewException() {
		
	}
	public ReviewException(String message) {
		super(message);
	}
}
