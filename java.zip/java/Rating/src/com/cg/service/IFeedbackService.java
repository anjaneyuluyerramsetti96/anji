package com.cg.service;

import java.util.Map;

import com.cg.exception.FeedbackException;

public interface IFeedbackService {

	boolean validateName(String name) throws FeedbackException;

	boolean validateRating(int rating) throws FeedbackException;

	boolean validateTopic(String topic) throws FeedbackException;

	Map<String, Integer> addFeedbackDetails(String name, int rating, String topic);

	Map<String, Integer> getFeedbackReport();

}
