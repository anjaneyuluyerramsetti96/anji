package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

public class FeedbackDao implements IFeedbackDao {
   Map<String, Integer>mathFeedback=new HashMap<String, Integer>();
   Map<String, Integer>englishFeedback=new HashMap<String, Integer>();
   Map<String, Integer>feedbackMap=new HashMap<String, Integer>();
	@Override
	
		

		public Map<String, Integer> addFeedbackDetails(String name, int rating, String topic) {
			if(topic.equalsIgnoreCase("math")) {
				if(feedbackMap.containsKey(name)) {
					if(rating<feedbackMap.get(name))
					{
						feedbackMap.put(name, feedbackMap.get(name));
					}
					else {
						feedbackMap.put(name, rating);
					}
				}
				else {
					feedbackMap.put(name, rating);
				}
				mathFeedback.put(name, rating);
				return mathFeedback;
			}
			else {
				if(feedbackMap.containsKey(name)) {
					if(rating<feedbackMap.get(name)) {
						feedbackMap.put(name, feedbackMap.get(name));
					}
					else {
						feedbackMap.put(name, rating);
					}
				}
				else {
					feedbackMap.put(name, rating);
				}
				englishFeedback.put(name, rating);
				return englishFeedback;
			}
			
		}

		public Map<String, Integer> getFeedbackReport() {
			
			return feedbackMap;
		}
}
