package com.capgemini.store.dao;

import java.util.Map;
import com.capgemini.store.bean.Album;
import com.capgemini.store.utility.AlbumDetails;

public class AlbumDaoImpl implements AlbumDao {
  Map<Integer, Album>albums=AlbumDetails.getMap();
	@Override
	public int saveAlbum(Album album) {
		int generatedId=(int) (Math.random()*1000);
	    album.setAlbumId(generatedId);
		albums.put(generatedId,album);
		return generatedId;
	}
	@Override
	public Album albumFind(int albumId) {
	     Album view=albums.get(albumId);
		return view;
	}
}
