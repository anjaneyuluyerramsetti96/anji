package com.cg.project.dao;

public class DaoImpl implements Dao {

}
