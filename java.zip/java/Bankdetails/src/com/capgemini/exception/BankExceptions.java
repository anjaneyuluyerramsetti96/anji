package com.capgemini.exception;

public class BankExceptions extends Exception{
   
	public BankExceptions(String message)
	{
		super(message);
	}
}
