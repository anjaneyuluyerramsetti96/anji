package com.cg.project.service;

import com.cg.project.exception.PSException;

public interface Service {

	public boolean isNameValid(String productName) throws PSException;

	public boolean isCostValid(int productCost)throws PSException;

}
