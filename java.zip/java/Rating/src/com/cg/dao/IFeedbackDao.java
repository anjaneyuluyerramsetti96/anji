package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

public interface IFeedbackDao {

	Map<String, Integer> addFeedbackDetails(String name, int rating, String topic);
	Map<String, Integer>feedbackMap=new HashMap<String, Integer>();
	Map<String, Integer> getFeedbackReport();
}
