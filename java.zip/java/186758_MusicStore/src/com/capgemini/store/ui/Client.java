package com.capgemini.store.ui;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.AlbumException;
import com.capgemini.store.service.AlbumService;
import com.capgemini.store.service.AlbumServiceImpl;
public class Client {

	public static void main(String[] args) {
		AlbumService service=new AlbumServiceImpl();
		Scanner scanner = null;
		int choice = 0;
		String artist = " ";
		String title = "";
		String topic = " ";
		int albumId=0;
		int price=0;
		double rating=0;
		boolean priceFlag=false;
		boolean choiceFlag = false;
		boolean albumFlag = false;
		boolean titleFlag = false;
		boolean topicFlag = false;
		boolean artistFlag = false;
		boolean ratingFlag=false;
		boolean optionFlag=false;
		try {
			do {
				System.out.println("1.Add Music Album");
				System.out.println("2.Find Album by id");
				System.out.println("3.Exit");
				scanner = new Scanner(System.in);

				System.out.println("Enter your choice");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter album id");
							albumId = scanner.nextInt();
							albumFlag= true;
						} catch (InputMismatchException e) {
							albumFlag = false;
							System.err.println("enter only digits");
						}
					} while (!albumFlag);
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter title");
							title = scanner.nextLine();
							service.isTitleValid(title);
							titleFlag = true;
						} catch (AlbumException e) {
							titleFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!titleFlag);
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter artist");
							artist = scanner.nextLine();
							service.isArtistValid(artist);
							artistFlag = true;
						} catch (AlbumException e) {
							topicFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!artistFlag);
				    
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter price");
							price = scanner.nextInt();
							service.isPriceValid(price);
							priceFlag = true;
						} catch (AlbumException e) {
							priceFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!priceFlag);
					
					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter rating");
							rating = scanner.nextDouble();
							service.isRatingValid(rating);
							ratingFlag = true;
						} catch (AlbumException e) {
							ratingFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!ratingFlag);
					Album album=new Album(albumId, title, artist, price, rating);
					
						int generatedId = service.saveAlbum(album);
				        System.out.println("album stored with Id:" + generatedId);
					
					break;

				case 2:
					System.out.println("Enter album id to find");
				      int albumid=scanner.nextInt();
				      Album c=service.albumFind(albumid);
				      System.out.println(c);
					break;
				case 3:
					System.out.println("Thank you,visit again!");
					System.exit(0);
					break;

				default:
					System.err.println("Choice should be only 1,2 and 3 only");
					break;
				}
				
				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Thank you,Visit Again!"); 
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Choice should be only 1,2 and 3 only");
		}finally {
			scanner.close();
		}
		
		
	}
	  
}
