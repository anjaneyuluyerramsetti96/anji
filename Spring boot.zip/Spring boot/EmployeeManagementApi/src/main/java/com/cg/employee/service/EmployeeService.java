package com.cg.employee.service;

import java.util.List;

import com.cg.employee.Exception.EmployeeException;
import com.cg.employee.dto.Employee;


public interface EmployeeService {

	List<Employee> viewEmployeeList() throws EmployeeException;
	List<Employee> createEmployee(Employee employee) throws EmployeeException;
	List<Employee> deleteEmployee(int id) throws EmployeeException;
	Employee findEmployeeById(int id) throws EmployeeException;
	List<Employee> updateEmployee(Employee employee) throws EmployeeException;
	List<Employee> viewEmployeeByDepartment(String deptName) throws EmployeeException;
}
